
package csx55.transport;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TCPConnectionTest {
    @Test
    public void testDummy() {
        assertTrue(true);
    }
}
