
package csx55.threads;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ComputeNodeTest {
    @Test
    public void testDummy() {
        assertTrue(true);
    }
}
