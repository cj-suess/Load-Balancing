
package csx55.threads;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RegistryTest {
    @Test
    public void testDummy() {
        assertTrue(true);
    }
}
