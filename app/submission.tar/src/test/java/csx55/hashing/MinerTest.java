package csx55.hashing;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MinerTest {
    @Test
    public void testDummy() {
        assertTrue(true);
    }
}