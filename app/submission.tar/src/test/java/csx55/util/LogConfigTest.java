
package csx55.util;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LogConfigTest {
    @Test
    public void testDummy() {
        assertTrue(true);
    }
}
