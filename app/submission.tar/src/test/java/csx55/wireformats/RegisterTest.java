
package csx55.wireformats;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RegisterTest {
    @Test
    public void testDummy() {
        assertTrue(true);
    }
}
